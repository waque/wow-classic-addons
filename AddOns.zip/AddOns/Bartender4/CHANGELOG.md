# Bartender4

## [4.8.5](https://github.com/Nevcairiel/Bartender4/tree/4.8.5) (2019-08-31)
[Full Changelog](https://github.com/Nevcairiel/Bartender4/compare/4.8.4...4.8.5)

- Tweak micromenu button layout on Classic  
- Fix Vehicle Bar moving on Classic  
