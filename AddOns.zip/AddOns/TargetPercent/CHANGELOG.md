# TargetPercent

## [v8.2.0](https://github.com/funkydude/TargetPercent/tree/v8.2.0) (2019-06-26)
[Full Changelog](https://github.com/funkydude/TargetPercent/compare/v8.0.0...v8.2.0)

- bump toc  
- fix curse link  
