# Vendor Price

## [1.1.4](https://github.com/ketho-wow/VendorPrice/tree/1.1.4) (2019-08-30)
[Full Changelog](https://github.com/ketho-wow/VendorPrice/compare/1.1.3...1.1.4)

- Fixed prices not being shown for equipment items while at the vendor  
    Fixed character bags not showing a price  
- Fixed showing price of stacks in /bagnon bank @kebabstorm  
